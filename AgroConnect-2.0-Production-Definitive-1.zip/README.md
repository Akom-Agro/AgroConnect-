# AgroConnect 2.0 — Production

Version de production préparée pour déploiement web/PWA. Cette version n'utilise aucune donnée de démonstration lorsqu'elle est configurée avec Supabase.

## 1. Prérequis
- Node.js 20+
- Un projet Supabase
- URL Supabase et clé publique anon

## 2. Configuration
Copier `.env.example` vers `.env.local` et renseigner :
- `VITE_SUPABASE_URL`
- `VITE_SUPABASE_ANON_KEY`

Ne jamais placer une `service_role` ou autre clé secrète dans une variable `VITE_*`.

## 3. Base de données
Dans Supabase > SQL Editor, exécuter `docs/supabase_schema.sql` sur un projet neuf ou après sauvegarde si une base existe déjà.

Le script crée les tables, le trigger de profil, le catalogue des cultures et les politiques RLS de base.

## 4. Test local
```bash
npm install
npm run build
npm run dev
```

## 5. Déploiement Netlify
- Build command : `npm run build`
- Publish directory : `dist`
- Variables d'environnement : `VITE_SUPABASE_URL`, `VITE_SUPABASE_ANON_KEY`

Le fichier `netlify.toml` est inclus.

## 6. Premier compte administrateur
Créer un compte normalement. Puis, depuis Supabase SQL Editor, après vérification de son UUID :
```sql
update public.profiles set role='admin' where id='UUID_DU_COMPTE';
```
Cette opération doit être faite uniquement par le propriétaire de la base.

## 7. Avant le lancement public
Cette livraison rend opérationnels Auth, profils, fermes, champs, cultures, prévisions, marché/appels ouverts, création d'appels côté acheteur, notifications et statistiques administrateur. Les fonctions IA complète, paiement réel, push et workflow complet de réponse/acceptation doivent être déployés via leurs services serveur avant de les annoncer comme disponibles.

## 8. Sécurité
RLS est activé. Tester obligatoirement avec deux comptes Producteur distincts, un Acheteur et un compte Ouvrier avant mise en production.
