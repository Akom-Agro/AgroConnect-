#!/usr/bin/env bash
set -euo pipefail
: "${VITE_SUPABASE_URL:?VITE_SUPABASE_URL is required}"
: "${VITE_SUPABASE_ANON_KEY:?VITE_SUPABASE_ANON_KEY is required}"
npm run build
test -f dist/index.html
echo "AgroConnect 2.0 build OK — publish dist/"
