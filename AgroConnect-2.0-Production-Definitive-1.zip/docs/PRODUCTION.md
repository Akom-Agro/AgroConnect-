# AgroConnect 2.0 — Dossier de production

Ce dossier est la base destinée au déploiement réel. Il est conçu pour être construit par Netlify à partir du code source.

## Ce qui est réel dans cette livraison
- Authentification Supabase e-mail/mot de passe.
- Création automatique du profil à l'inscription.
- Gestion des rôles Producteur / Acheteur / Ouvrier / Admin.
- Fermes et champs persistants.
- GPS du navigateur pour renseigner un champ.
- Catalogue de cultures.
- Calcul de date de récolte à partir du cycle de la culture.
- Appels d'offres persistants.
- Marché basé sur les appels d'offres ouverts.
- Notifications persistantes.
- Statistiques administrateur.
- RLS de base et protection du rôle.
- PWA/Netlify.

## Ce qui exige un service externe avant annonce publique
- Diagnostic IA : la fonction serveur doit être reliée à un fournisseur IA et à sa clé secrète.
- Paiements : aucun paiement ne doit être simulé ; connecter le fournisseur choisi et ses webhooks.
- Notifications push : connecter le fournisseur choisi si elles sont nécessaires.
- Cartographie avancée : ajouter Leaflet/OpenStreetMap lorsque les marqueurs persistants doivent être affichés ; le GPS du navigateur est déjà géré.

## Pourquoi ces éléments ne sont pas simulés
Une version de production ne doit jamais afficher « paiement réussi », « diagnostic IA terminé » ou « notification push envoyée » sans que le service réel ait confirmé l'opération.
