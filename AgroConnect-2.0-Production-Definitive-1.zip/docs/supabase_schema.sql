-- AgroConnect 2.0 — production schema + RLS
create extension if not exists pgcrypto;

create table if not exists public.profiles (
 id uuid primary key references auth.users(id) on delete cascade,
 full_name text,
 phone text,
 role text not null default 'producteur' check (role in ('producteur','acheteur','ouvrier','admin')),
 country text default 'Cameroun',
 created_at timestamptz not null default now()
);
create table if not exists public.farms (
 id uuid primary key default gen_random_uuid(), owner_id uuid not null references public.profiles(id) on delete cascade,
 name text not null, area_ha numeric(12,2) not null default 0, region text, created_at timestamptz not null default now()
);
create table if not exists public.crops (
 id uuid primary key default gen_random_uuid(), name text not null unique, icon text, cycle_days integer not null default 90, active boolean not null default true
);
create table if not exists public.fields (
 id uuid primary key default gen_random_uuid(), farm_id uuid not null references public.farms(id) on delete cascade,
 crop_id uuid references public.crops(id), name text not null, area_ha numeric(12,2) not null default 0,
 planting_date date, latitude double precision, longitude double precision, created_at timestamptz not null default now()
);
create table if not exists public.harvest_forecasts (
 id uuid primary key default gen_random_uuid(), field_id uuid not null references public.fields(id) on delete cascade,
 estimated_date date, estimated_volume_kg numeric(14,2), status text not null default 'growth', created_at timestamptz not null default now()
);
create table if not exists public.tenders (
 id uuid primary key default gen_random_uuid(), buyer_id uuid not null references public.profiles(id) on delete cascade,
 crop_id uuid references public.crops(id), volume_kg numeric(14,2) not null check(volume_kg>0), delivery_from date,
 delivery_to date, tolerance_days integer not null default 15, price_note text, delivery_zone text,
 status text not null default 'open' check(status in ('open','closed','cancelled')), created_at timestamptz not null default now()
);
create table if not exists public.tender_responses (
 id uuid primary key default gen_random_uuid(), tender_id uuid not null references public.tenders(id) on delete cascade,
 producer_id uuid not null references public.profiles(id) on delete cascade, field_id uuid not null references public.fields(id) on delete cascade,
 offered_volume_kg numeric(14,2) not null check(offered_volume_kg>0), estimated_harvest_date date,
 status text not null default 'pending' check(status in ('pending','accepted','rejected')), created_at timestamptz not null default now()
);
create table if not exists public.notifications (
 id uuid primary key default gen_random_uuid(), user_id uuid not null references public.profiles(id) on delete cascade,
 title text not null, body text, type text not null default 'system', read_at timestamptz, created_at timestamptz not null default now()
);

alter table public.profiles enable row level security;
alter table public.farms enable row level security;
alter table public.fields enable row level security;
alter table public.harvest_forecasts enable row level security;
alter table public.tenders enable row level security;
alter table public.tender_responses enable row level security;
alter table public.notifications enable row level security;

create or replace function public.handle_new_user() returns trigger language plpgsql security definer set search_path=public as $$
begin insert into public.profiles(id,full_name,phone,role,country) values(new.id,new.raw_user_meta_data->>'full_name',new.raw_user_meta_data->>'phone',coalesce(new.raw_user_meta_data->>'role','producteur'),'Cameroun') on conflict(id) do nothing; return new; end; $$;
drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created after insert on auth.users for each row execute procedure public.handle_new_user();

create or replace function public.is_admin() returns boolean language sql stable security definer set search_path=public as $$ select exists(select 1 from public.profiles where id=auth.uid() and role='admin'); $$;

create or replace function public.prevent_client_role_change() returns trigger language plpgsql security definer set search_path=public as $$
begin
  if old.role is distinct from new.role and not public.is_admin() then
    raise exception 'Role modification is restricted to administrators';
  end if;
  return new;
end; $$;
drop trigger if exists prevent_client_role_change on public.profiles;
create trigger prevent_client_role_change before update on public.profiles for each row execute procedure public.prevent_client_role_change();

-- Profiles: user can read/update own non-role fields. Role cannot be changed by client.
drop policy if exists profiles_select_self on public.profiles; create policy profiles_select_self on public.profiles for select using (id=auth.uid() or public.is_admin());
drop policy if exists profiles_update_self on public.profiles; create policy profiles_update_self on public.profiles for update using (id=auth.uid() or public.is_admin()) with check (id=auth.uid() or public.is_admin());

-- Farms
create policy farms_select_owner on public.farms for select using (owner_id=auth.uid() or public.is_admin());
create policy farms_insert_owner on public.farms for insert with check (owner_id=auth.uid());
create policy farms_update_owner on public.farms for update using (owner_id=auth.uid() or public.is_admin()) with check (owner_id=auth.uid() or public.is_admin());
create policy farms_delete_owner on public.farms for delete using (owner_id=auth.uid() or public.is_admin());

-- Crops: catalogue public to authenticated users, admin manages.
create policy crops_select_auth on public.crops for select to authenticated using (active=true or public.is_admin());
create policy crops_admin_insert on public.crops for insert with check (public.is_admin());
create policy crops_admin_update on public.crops for update using (public.is_admin()) with check (public.is_admin());
create policy crops_admin_delete on public.crops for delete using (public.is_admin());

-- Fields: owner of farm or admin.
create policy fields_select_owner on public.fields for select using (exists(select 1 from public.farms f where f.id=farm_id and (f.owner_id=auth.uid() or public.is_admin())));
create policy fields_insert_owner on public.fields for insert with check (exists(select 1 from public.farms f where f.id=farm_id and f.owner_id=auth.uid()));
create policy fields_update_owner on public.fields for update using (exists(select 1 from public.farms f where f.id=farm_id and (f.owner_id=auth.uid() or public.is_admin()))) with check (exists(select 1 from public.farms f where f.id=farm_id and (f.owner_id=auth.uid() or public.is_admin())));
create policy fields_delete_owner on public.fields for delete using (exists(select 1 from public.farms f where f.id=farm_id and (f.owner_id=auth.uid() or public.is_admin())));

-- Forecasts
create policy forecast_select_owner on public.harvest_forecasts for select using (exists(select 1 from public.fields fi join public.farms f on f.id=fi.farm_id where fi.id=field_id and (f.owner_id=auth.uid() or public.is_admin())));
create policy forecast_insert_owner on public.harvest_forecasts for insert with check (exists(select 1 from public.fields fi join public.farms f on f.id=fi.farm_id where fi.id=field_id and f.owner_id=auth.uid()));
create policy forecast_update_owner on public.harvest_forecasts for update using (exists(select 1 from public.fields fi join public.farms f on f.id=fi.farm_id where fi.id=field_id and (f.owner_id=auth.uid() or public.is_admin()))) with check (exists(select 1 from public.fields fi join public.farms f on f.id=fi.farm_id where fi.id=field_id and (f.owner_id=auth.uid() or public.is_admin())));
create policy forecast_delete_owner on public.harvest_forecasts for delete using (exists(select 1 from public.fields fi join public.farms f on f.id=fi.farm_id where fi.id=field_id and (f.owner_id=auth.uid() or public.is_admin())));

-- Tenders: authenticated can see open tenders; buyer manages own; admin all.
create policy tenders_select on public.tenders for select to authenticated using (status='open' or buyer_id=auth.uid() or public.is_admin());
create policy tenders_insert_buyer on public.tenders for insert with check (buyer_id=auth.uid() and exists(select 1 from public.profiles where id=auth.uid() and role in ('acheteur','admin')));
create policy tenders_update_buyer on public.tenders for update using (buyer_id=auth.uid() or public.is_admin()) with check (buyer_id=auth.uid() or public.is_admin());
create policy tenders_delete_buyer on public.tenders for delete using (buyer_id=auth.uid() or public.is_admin());

-- Tender responses: producer manages own responses; buyer can read responses to own tenders and update status.
create policy responses_select on public.tender_responses for select using (producer_id=auth.uid() or exists(select 1 from public.tenders t where t.id=tender_id and t.buyer_id=auth.uid()) or public.is_admin());
create policy responses_insert on public.tender_responses for insert with check (producer_id=auth.uid() and exists(select 1 from public.profiles where id=auth.uid() and role='producteur'));
create policy responses_update on public.tender_responses for update using (producer_id=auth.uid() or exists(select 1 from public.tenders t where t.id=tender_id and t.buyer_id=auth.uid()) or public.is_admin()) with check (producer_id=auth.uid() or exists(select 1 from public.tenders t where t.id=tender_id and t.buyer_id=auth.uid()) or public.is_admin());

-- Notifications
create policy notifications_select on public.notifications for select using (user_id=auth.uid() or public.is_admin());
create policy notifications_update on public.notifications for update using (user_id=auth.uid() or public.is_admin()) with check (user_id=auth.uid() or public.is_admin());
create policy notifications_insert_service on public.notifications for insert with check (public.is_admin());

insert into public.crops(name,icon,cycle_days) values
('Tomate','🍅',90),('Maïs','🌽',100),('Pastèque','🍉',90),('Légumes','🥬',60),('Plantain','🍌',300),('Avocat','🥑',180)
on conflict(name) do update set icon=excluded.icon, cycle_days=excluded.cycle_days, active=true;
